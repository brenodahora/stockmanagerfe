import { Router } from 'express';
import loginValidation from '../app/validation/loginValidation';
import UserController from '../app/controller/loginController';

const router = Router();
const protect = require("../app/token/auth");

router.post('/api/v1/user', loginValidation, UserController.createUser);
router.post('/api/v1/authenticate', loginValidation, UserController.authenticate);
router.get('/api/v1/user', protect, UserController.findAllUser);
router.delete('/api/v1/user/:id', protect, UserController.deleteUser);
router.post('/api/v1/validatetoken', protect, UserController.validateToken);

export default router;
