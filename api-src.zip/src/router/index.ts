import RouterProduct from './routerProduct';
import RouterLogin from './routerLogin';

export default [RouterProduct, RouterLogin];
