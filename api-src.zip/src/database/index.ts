import mongoose from 'mongoose';
import 'dotenv/config';

class Database {
    constructor() {
        this.connect();
    }
    connect() {
        const MONGO_DB_URL = `mongodb://${process.env.DB_NAME}:${process.env.DB_PASS}@${process.env.DB_HOST}:${process.env.DB_PORT}`;
        mongoose.connect(MONGO_DB_URL);
        mongoose.connection.on('error', console.log.bind(console, 'Error connection'));
        mongoose.connection.once('open', () => {
            console.log(`Connected database. Host: @${process.env.DB_HOST}:${process.env.DB_PORT}`);
        });

        return mongoose.connection;
    }
}

export default new Database().connect;