import { Types } from 'mongoose';

export interface LoginInterface {
    email: string;
    senha: string;
    name: string;
}

export interface LoginInterfaceResponse {
    _id: Types.ObjectId;
    email: string;
    senha: string;
    name: string;
}
