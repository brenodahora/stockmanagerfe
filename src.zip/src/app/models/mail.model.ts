export interface Mail {
    Subject: string,
    Text: string,
    Name: string,
    Email: string
}