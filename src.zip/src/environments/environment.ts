export const environment = {
    api: '',
    webhookmail: ''
};
