export const environment = {
    api: 'http://172.18.10.21:3000/api/v1',
    webhookmail: "https://hook.us1.make.com/qnhly0v8dln4vg839e3tgglm7fgsg4m8"
};
